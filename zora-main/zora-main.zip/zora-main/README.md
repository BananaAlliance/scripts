# Zora Ultimate Soft

 - [Bridge from Ethereum to Zora](https://bridge.zora.energy/)
 - Mint any NFT from your own list
 - Earn mint.fun points
 - Create collections
 - Update collections

### Follow: https://t.me/timfamecode

### Settings
`files/wallets.txt` - Wallets with private keys \
`files/proxies.txt` - Corresponding proxies for wallets \
`config.py` - Custom settings \
`vars.py` - Contracts info 

### Run

Installing all dependencies: \
`pip3 install -r requirements.txt`

Run script: \
`python3 main.py`

### Results

`results/` - Folder with results by datetime of run \
`logs/` - Folder with logs by datetime of run

### Donate :)

TRC-20 - `TX7yeJVHwhNsNy4ksF1pFRFnunF1aFRmet` \
ERC-20 - `0x5aa3c82045f944f5afa477d3a1d0be3c96196319`
