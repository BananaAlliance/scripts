### Установка

`git clone https://github.com/munris-vlad/scroll`

`npm install`

Вписываем приватники в файл `private_keys.txt`

Запуск `npm start`

Настройки `config.ts`

### Возможности

* Официальный бридж ETH -> Scroll
* Orbiter Arbitrum -> Scroll
* Merkly refuel Arbitrum, Optimism, Avalanche, Polygon, Base -> Scroll
* Scrollswap
* Deploy contract

Все дексы делают round swap ETH -> Stable (USDC/DAI) -> ETH

Есть возможность сделать рандом модуль (кроме бриджей), рандом только свап модули, свапнуть все стейблы в ETH